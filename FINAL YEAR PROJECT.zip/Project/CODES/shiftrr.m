%Function for shifting matrix right to right 
  function sht=shiftrr(ma,mdm,row)
%STEP 1:Initialize the shifting units
  A=ma;
  n=mdm; %Shift units
  n=double(n);
  C=A;
  C(row,1:end-n)=A(row,n+1:end);
  C(row,end-n+1:end)=A(row,1:n);
  sht=C;
  end
