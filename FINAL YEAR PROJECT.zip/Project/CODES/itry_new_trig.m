function re=itry_new_trig(a)

%a=imread('cipherimage.png');
%ori=entropy(a);
figure;
imshow(a);title('cipherimage');
%rn=imread('diffused red.png');
CR=(a(:,:,1));
CG=(a(:,:,2));
CB=(a(:,:,3));
 figure;
 imshow(CR);title('diffused red');
 figure;
 imshow(CG);title('diffused green');
 figure;
 imshow(CB);title('diffused blue');
 CR = reshape(CR,[1,65536]);
 CG = reshape(CG,[1,65536]);
 CB = reshape(CB,[1,65536]);
 CR=uint8(CR);
 CG=uint8(CG);
 CB=uint8(CB);
aR=trignox(1.5,0.5); 
aG=trignoy(1.5,0.5);
aB=aR;
 
HR=imread('rhde.png');
HG=imread('ghde.png');
HB=imread('bhde.png');

HR= reshape(HR,[1,65536]);
HG= reshape(HG,[1,65536]);
HB= reshape(HB,[1,65536]);

HR=uint8(HR);
HG=uint8(HG);
HB=uint8(HB);

S1=mod((aR*(10.^10)),256);
S2=mod((aG*(10.^10)),256);
S3=mod((aB*(10.^10)),256);

S1=uint8(S1);
S2=uint8(S2);
S3=uint8(S3);

 % diffusion using XORed Hamming and Confused R,G,B
      XR=[];
      XG=[];
      XB=[];
      for i=1:65536;
        XR(i)=bitxor(HR(i),S1(i));
        XG(i)=bitxor(HG(i),S2(i));
        XB(i)=bitxor(HB(i),S3(i));
      end
      
% diffusion using XORed Hamming and Confused R,G,B
      SR=[];
      SG=[];
      SB=[];
      for i=1:65536;
        SR(i)=mod(((bitxor(CR(i),XR(i)))),256);
        SG(i)=mod(((bitxor(CG(i),XG(i)))),256);
        SB(i)=mod(((bitxor(CB(i),XB(i)))),256);
      end

T=reshape(SR,[256,256]);
U=reshape(SG,[256,256]);
V=reshape(SB,[256,256]);
mdset=md();
%find minimum element
%1=coloumn min 2=row min
rxtp=T;
gxtp=U;
bxtp=V;

    for j=1:256;
      mdm(j)=maximum(mdset,j,1);
      rm(j)=maximum(T,j,2);
      gm(j)=maximum(U,j,2);
      bm(j)=maximum(V,j,2);
      
      %shift to right with  mdm check
      if mdm(j)<=rm(j);
            rxtp=shiftrr(rxtp,mdm(j),j);
            %rxt=rxtp;
      else
          rxtp=shiftlr(rxtp,mdm(j),j);
      end
      if mdm(j)<=gm(j);
            gxtp=shiftrr(gxtp,mdm(j),j);
            %gxt=gxtp;
      else
         gxtp=shiftlr(gxtp,mdm(j),j); 
      end
      if mdm(j)<=bm(j);
             bxtp=shiftrr(bxtp,mdm(j),j);
            %bxt=bxtp;
      else
         bxtp=shiftlr(bxtp,mdm(j),j);
      end
    end
   
    
    XDR=reshape(rxtp,[1,65536]);
    XDG=reshape(gxtp,[1,65536]);
    XDB=reshape(bxtp,[1,65536]);
    
   R=[];
   G=[];
   B=[];
   
  for i=1:65536  
R(i)=bitxor(XDR(i),S1(i));
G(i)=bitxor(XDG(i),S2(i));
B(i)=bitxor(XDB(i),S3(i));
  end
 

r = reshape(R,256,256);
t = reshape(G,256,256);
i = reshape(B,256,256);
r=uint8(r);
t=uint8(t);
i=uint8(i);

figure;
subplot(2,2,1);imshow(r);title('aR');
subplot(2,2,2);imshow(t);title('aG');
subplot(2,2,3);imshow(i);title('aB');
% I=imread('itest.bmp');
aa=cat(3,r,t,i);  
subplot(2,2,4); imshow(aa); title('Decrypted');
imwrite(aa,'itest.png');
ore=entropy(aa)
re=aa;
end
    