function anss= trignox(x,y)
w=100*pi;
r=2;
H = double(zeros(256,256,1));
H= reshape(H,[1,65536]);

for n=1:65536
   x=sind(w*x)-(r*(sind(w*y)));
   y=cosd(w*x);
   H(n)=x;
end
anss=H;
end