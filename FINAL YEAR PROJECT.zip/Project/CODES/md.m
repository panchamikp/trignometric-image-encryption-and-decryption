%Function for calculate mandelbrot set by using Modified mandelbrot set 
  function W=md()
%STEP 1:Initial values for modified mandelbrot set
  col=20;
  m=256;
  cx=-.6;
  cy=0;
  l=1.5;
%STEP 2:Generation of original mandelbrot set
  x=linspace(cx-l,cx+l,m);
  y=linspace(cy-l,cy+l,m);
  [X,Y]=meshgrid(x,y);
  Z=zeros(m);
  C=X+i*Y;
  for k=1:col;
  Z=Z.^2+C;
  W=exp(-abs(Z));
  end
%STEP 3:Generation of modified mandelbrot set
  KE=25;
  for m=1:256;
    for j=1:256;
        if W(m,j)==0;
            W(m,j)=mod(((m*j)+KE),256);
        end
    end
  end
  W=uint8(W);
  end
