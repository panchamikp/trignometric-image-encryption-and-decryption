function [X,Y]=trigmain(siz)
  X=trignox_t(1.5,0.9,siz);
  Y=trignoy_t(1.5,0.9,siz);

end
