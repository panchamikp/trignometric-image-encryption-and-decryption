%Input the image name 
    a=imread('lena.png');

%Function call- Encryption
    b=try_new_trig(a);

%Function call- Decryption
    c=itry_new_trig(b);