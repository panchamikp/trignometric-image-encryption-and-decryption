%Function for find max value of a matrix 
  function min=maximum(ma,ro,rc)
%STEP 1: rc=2 means row
  if(rc==2);
  me=ma(ro,1);  
  for i=1:256;
    if ma(ro,(i))>=me;
        me=ma(ro,(i));
    end
  end
  min=me;
  end
%STEP 2: rc=1 means coloumn
  if(rc==1);
    me=ma(1,ro);
    for i=1:256;
    
    if ma(i,ro)>=me;
        me=ma(i,ro);
    end
  end
  min=me;
  end
 end
