function X= trignox_t(x,y,siz)
w=147*pi;
r=2;
H = double(zeros(siz,siz,1));
m=siz*siz;
H= reshape(H,[1,m]);

for n=1:m
   x=sind(w*x)-(r*(sind(w*y)));
   y=cosd(w*x);
   H(n)=x;
end
H= reshape(H,[siz,siz]);
X=H;
end