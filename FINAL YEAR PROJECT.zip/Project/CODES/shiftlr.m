%Function for shifting matrix left to right 
  function sht=shiftlr(ma,mdm,row)
%Initialize the shifing units 
  A=ma;
  B=A;
  n=mdm; %Shift units
  n=double(n);
  B(row,n+1:end)=A(row,1:end-n);
  B(row,1:n)=A(row,end-n+1:end);
  sht=B;
  end
