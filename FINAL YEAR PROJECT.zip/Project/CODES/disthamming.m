%Function for calculate hamming distance 
  function [ sum ] = disthamming(x,y)

           sum=0;
           z = bitxor(x, y);
        for i=1:8
            sum = sum + bitget(z,i);
        end
    end

