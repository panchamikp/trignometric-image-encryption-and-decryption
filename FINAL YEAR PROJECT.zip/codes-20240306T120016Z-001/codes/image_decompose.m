function [R,G,B]=image_decompose(A)

% Decompose in to R,G,B
%--------------------------------------------
   R=A(:,:,1); 
   G=A(:,:,2);
   B=A(:,:,3); 

% R,G,B Channels
%------------------------------------------
% figure;
% subplot(2,2,1); imshow(A);title(' Original');
% subplot(2,2,2); imshow(R);title(' Red channel');
% subplot(2,2,3); imshow(G);title(' Green channel');
% subplot(2,2,4); imshow(B);title(' Blue channel');
%-------------------------------------------
end