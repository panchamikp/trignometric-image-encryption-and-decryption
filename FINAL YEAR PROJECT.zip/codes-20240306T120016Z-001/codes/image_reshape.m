function [R,G,B]=image_reshape(p,q,m)
%--------------------------------------------
% Reshaping in to single dimension for Hamming Distance
%-------------------------------------------
%Find size of the images 
[height, width] = find_size(p);
M=height*width;
%-------------------------------------------
 r = reshape(p,[1,M]);
 g = reshape(q,[1,M]);
 b = reshape(m,[1,M]);

%--------------------------------------------
% Normalizing into Uint 8
%------------------------------------------
 R=uint8(r);
 G=uint8(g);
 B=uint8(b);
%------------------------------------------
end