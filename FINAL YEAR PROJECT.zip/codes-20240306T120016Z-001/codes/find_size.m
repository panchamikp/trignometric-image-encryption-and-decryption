function [height,width]=find_size(IM)
%-----------------------------------
%Find size of an image using size function
%---------------------------------------
[height, width] = size(IM);
%--------------------------------------

end