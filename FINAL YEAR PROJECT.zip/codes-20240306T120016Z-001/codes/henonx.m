
% key generation using Chaotic map function (Henon map)
function [out]=henonx(x,y,a,b,siz)
%STEP1 : Creating an empty martrix for keys

  k = double(zeros(siz,siz));
%STEP 2: Reading initial & parameter values
   r= 1 ; % Number of iteration
   
  for j=1:r

   for i = 1:65536
       d(i)= 1-(a*(x*x))+y;
       c(i)=(b*x);
       y=c(i);
       x=d(i);    
   end
   end
k=d;
out= reshape(k,[siz,siz]);
end
