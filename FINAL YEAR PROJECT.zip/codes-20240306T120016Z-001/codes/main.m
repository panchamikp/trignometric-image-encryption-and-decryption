% Function call - Image Reading 
%-----------------------------------
    A=image_read('lena.png');
%----------------------------------
% Fuctton call - Image Decomposition
%-----------------------------------
   [R,G,B]=image_decompose(A);
%----------------------------------
% Function call- reshape 1D
%---------------------------------
[R,G,B]=image_reshape(R,G,B);
%---------------------------------
% Function call-  Encryption
%---------------------------------
  %C=trig_encryption(R,G,B);
%---------------------------------