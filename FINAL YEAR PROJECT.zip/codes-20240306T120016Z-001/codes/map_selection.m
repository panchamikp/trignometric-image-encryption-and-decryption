% Function call - Image Reading 
%-----------------------------------
    A=image_read('lena.png');
%----------------------------------
[height,width]=find_size(A);
%---------------------------------
%image decomposition 
[R,G,B]=image_decompose(A);
%--------------------------------

% 1-------------------------------
% Function call - Henon map
[X,Y]=hmain(height);
%-------------------------------
% function call map encrypt
cipentropy=map_encrypt(X,Y,R,G,B,height);
disp(['Cipher image entropy (henon):',num2str(cipentropy)]);
%---------------------------------------------------

% 2-------------------------------
% Function call - logistic map
[X,Y]=lmain(height);
%-------------------------------
% function call map encrypt
cipentropy=map_encrypt(X,Y,R,G,B,height);
disp(['Cipher image entropy(logistic):',num2str(cipentropy)]);
%---------------------------------------------------
% 3 Function call - lorenz map
[X,Y]=lomain(height);
%-------------------------------
% function call map encrypt
cipentropy=map_encrypt(X,Y,R,G,B,height);
disp(['Cipher image entropy(lorenz):',num2str(cipentropy)]);
% 4-------------------------------
% Function call - trigonometric map
[X,Y]=trigmain(height);
%-------------------------------
% function call map encrypt
cipentropy=map_encrypt(X,Y,R,G,B,height);
disp(['Cipher image entropy(trigonometric):',num2str(cipentropy)]);
%---------------------------------------------------
