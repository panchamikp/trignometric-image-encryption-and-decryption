function cipentropy=map_encrypt(X,Y,R,G,B,siz)
     si=siz*siz;
    X1=reshape(X,[1,si]);
    X2=reshape(Y,[1,si]);
    X3=reshape(X,[1,si]);
    X1=uint8(X1);
    X2=uint8(X2);
    X3=uint8(X3);
    R = reshape(R,[1,si]);
    G = reshape(G,[1,si]);
    B = reshape(B,[1,si]);
    R=uint8(R);
    G=uint8(G);
    B=uint8(B);
   % Normalized chaotic sequence
      S1=mod((X1*(10.^10)),siz);
      S2=mod((X2*(10.^10)),siz);
      S3=mod((X3*(10.^10)),siz);
      S1=uint8(S1);
      S2=uint8(S2);
      S3=uint8(S3);

%STEP 4: xor operation on R,G,B and chaotic sequence (S1,S2,S3):
   XDR=[];
   XDG=[];
   XDB=[];
   for i=1:si  
     XDR(i)=bitxor(R(i),S1(i));
     XDG(i)=bitxor(G(i),S2(i));
     XDB(i)=bitxor(B(i),S3(i));
   end
  XDR=uint8(XDR);
  XDG=uint8(XDG);
  XDB=uint8(XDB);

  DR=reshape(XDR,[siz,siz]);
  DG=reshape(XDG,[siz,siz]);
  DB=reshape(XDB,[siz,siz]);

  cipherimage=cat(3,DR,DG,DB);
         %figure;
         %imshow(cipherimage);title('cipherimage');
         imwrite(cipherimage,'cipherimage.png'); 
         ric=imread('cipherimage.png');
         cipentropy=entropy(ric);
end