function A=image_read(pl)

% Input Original Image 
%----------------------------------------------------

A=imread(pl); 	      % Reading Image
original_entropy=entropy(A);  % Finding Entropy
%-------------------------------------------------------
% Display the original Image
figure;
imshow(A);title('Original Image');

%-------------------------------------------------------
disp(['Entropy of Original image :',num2str(original_entropy)]);
% figure;
% histogram(A);title('Histogram of Original Image');

%-------------------------------------------------------
end