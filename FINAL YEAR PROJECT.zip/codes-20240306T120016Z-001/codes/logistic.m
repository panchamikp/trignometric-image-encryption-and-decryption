function [X,Y]=logistic(x,y,siz)
% key generation using Chaotic map function (Logistic map)
%STEP1 : Creating an empty martrix for keys
  k = double(zeros(siz,siz));
  
  r= 1 ; % Number of iteration
  for j=1:r
  for i = 1:siz*siz
      d(i)=(y*x)*(1-x);
      x=d(i);
  end
  end

     k=d;
     X= reshape(k,[siz,siz]);
     Y=X;
end
