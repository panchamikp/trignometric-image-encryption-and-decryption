
% key generation using Chaotic map function (Henon map)
function [out]=henony(x,y,a,b,siz)

%STEP1 : Creating an empty martrix for keys

  k = double(zeros(siz,siz));
  
%STEP 3: Initialize number of iteration for the map
   r= 1 ; % Number of iteration
   
  for j=1:r

   for i = 1:65536
       d(i)= 1-(a*(x*x))+y;
       c(i)=(b*x);
       y=c(i);
       x=d(i);    
   end
   end
k=c;
out= reshape(k,[siz,siz]);
end
