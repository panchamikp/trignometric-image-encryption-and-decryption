function [z1,z2] = lorenz(x,y,z,aa,bb,sgm,siz)
% ------------------------------------------

sigma = sgm;
beta = bb;
rho = aa;
a=x;
b=y;
c=z;
n=siz*siz;
if siz == 256
f = @(t,a) [-sigma*a(1) + sigma*a(2); rho*a(1) - a(2) - a(1)*a(3); -beta*a(3) + a(1)*a(2)];
[t,a] = ode45(f,[0 1111.6439],[a b c]);     % Runge-Kutta 4th/5th order ODE solver 
else
f = @(t,a) [-sigma*a(1) + sigma*a(2); rho*a(1) - a(2) - a(1)*a(3); -beta*a(3) + a(1)*a(2)];
[t,a] = ode45(f,[0 10000],[a b c]);     % Runge-Kutta 4th/5th order ODE solver
end
a1=a(:,1);
a2=a(:,2);
a3=a(:,3);

for i=1:n
    a4(i)=a1(i+1);
    a5(i)=a2(i+1);
    a6(i)=a3(i+1);
end

z1= reshape(a4,[siz,siz]);
z2= reshape(a5,[siz,siz]);
%z3= reshape(a6,[siz,siz]);
end


